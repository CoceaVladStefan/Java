package isp.lab9.exercise1.ui;

import javax.swing.*;

/**
 * todo: implement - it should look similar to the 'Buy' panel
 */
public class SellJPanel extends JPanel {


}
