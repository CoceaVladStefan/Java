package isp.lab9.exercise1.services;

public class UserPortfolioService {

    private String[] columns = new String[]{"Name", "Symbol", "Price", "Currency", "Change", "Exchange"};

}
