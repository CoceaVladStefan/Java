package isp.lab9.exercise1;

import isp.lab9.exercise1.ui.LoginJFrame;

/**
 * @author mihai.hulea
 * @author radu.miron
 */
public class Main {
    public static void main(String[] args) {
        new LoginJFrame();
    }
}
