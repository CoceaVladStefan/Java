package isp.lab8.airways;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AirwaysTest {

}
