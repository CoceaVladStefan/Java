package isp.lab5.exercise4;

public interface TicketsManager {

    int generateTicket();
    int validateTicket();
}