package isp.lab7.safehome;

public enum DoorStatus {
    OPEN, CLOSED
}
